#!/usr/bin/env python3
"""
Ubuntu Laptop Optimizer
=======================
Speeds up your Ubuntu system without deleting permanent files.
Only clears temporary/cache files that are safe to remove.

Run with: sudo python3 ubuntu_optimizer.py
"""

import subprocess
import os
import shutil
from pathlib import Path


class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BLUE = '\033[94m'
    BOLD = '\033[1m'
    END = '\033[0m'


def print_header(text):
    print(f"\n{Colors.BLUE}{Colors.BOLD}{'='*60}{Colors.END}")
    print(f"{Colors.BLUE}{Colors.BOLD}  {text}{Colors.END}")
    print(f"{Colors.BLUE}{Colors.BOLD}{'='*60}{Colors.END}")


def print_success(text):
    print(f"{Colors.GREEN}✓ {text}{Colors.END}")


def print_warning(text):
    print(f"{Colors.YELLOW}⚠ {text}{Colors.END}")


def print_error(text):
    print(f"{Colors.RED}✗ {text}{Colors.END}")


def run_command(cmd, description, shell=False):
    """Run a shell command and handle errors."""
    try:
        if shell:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        else:
            result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode == 0:
            print_success(description)
            return True
        else:
            print_warning(f"{description} (skipped or not applicable)")
            return False
    except Exception as e:
        print_error(f"{description}: {e}")
        return False


def check_root():
    """Check if running with root privileges."""
    if os.geteuid() != 0:
        print_error("This script requires root privileges. Please run with sudo.")
        print(f"\nUsage: {Colors.BOLD}sudo python3 {__file__}{Colors.END}")
        return False
    return True


def get_disk_space():
    """Get current disk usage."""
    stat = shutil.disk_usage("/")
    return stat.free // (1024 ** 3)  # Return free space in GB


def clear_apt_cache():
    """Clear APT package cache (downloaded .deb files)."""
    print_header("Clearing APT Cache")
    run_command(["apt-get", "clean"], "Cleared apt cache")
    run_command(["apt-get", "autoclean"], "Removed obsolete packages from cache")
    run_command(["apt-get", "autoremove", "-y"], "Removed unused dependencies")


def clear_old_kernels():
    """Remove old kernel versions (keeps current + 1 previous)."""
    print_header("Managing Old Kernels")
    run_command(
        "apt-get purge -y $(dpkg -l 'linux-*' | sed '/^ii/!d;/'\"$(uname -r | sed \"s/\\(.*\\)-\\([^0-9]\\+\\)/\\1/\")\"'/d;s/^[^ ]* [^ ]* \\([^ ]*\\).*/\\1/;/[0-9]/!d' | head -n -1) 2>/dev/null",
        "Removed old kernel versions",
        shell=True
    )


def clear_system_logs():
    """Clear old system logs (keeps recent logs)."""
    print_header("Managing System Logs")
    # Keep only last 3 days of journal logs
    run_command(
        ["journalctl", "--vacuum-time=3d"],
        "Cleaned journal logs older than 3 days"
    )
    # Limit journal size to 100MB
    run_command(
        ["journalctl", "--vacuum-size=100M"],
        "Limited journal size to 100MB"
    )


def clear_thumbnail_cache():
    """Clear thumbnail cache for all users."""
    print_header("Clearing Thumbnail Cache")
    home_dirs = Path("/home").iterdir()
    for home in home_dirs:
        thumb_dir = home / ".cache" / "thumbnails"
        if thumb_dir.exists():
            try:
                shutil.rmtree(thumb_dir)
                print_success(f"Cleared thumbnails for {home.name}")
            except Exception as e:
                print_warning(f"Could not clear thumbnails for {home.name}")


def clear_temp_files():
    """Clear temporary files."""
    print_header("Clearing Temporary Files")
    
    # Clear /tmp (safe - these are temporary by design)
    tmp_count = 0
    for item in Path("/tmp").iterdir():
        try:
            if item.is_file():
                item.unlink()
                tmp_count += 1
            elif item.is_dir() and item.name not in ['.X11-unix', '.ICE-unix', '.font-unix']:
                shutil.rmtree(item)
                tmp_count += 1
        except:
            pass
    print_success(f"Cleared {tmp_count} items from /tmp")
    
    # Clear /var/tmp (old files only)
    run_command(
        "find /var/tmp -type f -atime +7 -delete 2>/dev/null",
        "Cleared old files from /var/tmp",
        shell=True
    )


def clear_user_caches():
    """Clear user cache directories (safe temporary data)."""
    print_header("Clearing User Caches")
    
    home_dirs = Path("/home").iterdir()
    for home in home_dirs:
        cache_dir = home / ".cache"
        if cache_dir.exists():
            cleared = 0
            for item in cache_dir.iterdir():
                # Skip important caches, only clear safe ones
                safe_to_clear = [
                    'thumbnails', 'pip', 'yarn', 'npm', 'chromium',
                    'google-chrome', 'mozilla', 'fontconfig', 'mesa_shader_cache',
                    'tracker', 'tracker3', 'evolution', 'shotwell'
                ]
                if item.name in safe_to_clear:
                    try:
                        if item.is_dir():
                            shutil.rmtree(item)
                        else:
                            item.unlink()
                        cleared += 1
                    except:
                        pass
            if cleared > 0:
                print_success(f"Cleared {cleared} cache directories for {home.name}")


def clear_crash_reports():
    """Clear old crash reports."""
    print_header("Clearing Crash Reports")
    crash_dir = Path("/var/crash")
    if crash_dir.exists():
        count = 0
        for item in crash_dir.iterdir():
            try:
                item.unlink()
                count += 1
            except:
                pass
        print_success(f"Cleared {count} crash reports")


def optimize_swappiness():
    """Optimize swap usage for better performance."""
    print_header("Optimizing Swap Settings")
    
    # Set swappiness to 10 (default is 60, lower = less swap usage)
    run_command(
        ["sysctl", "-w", "vm.swappiness=10"],
        "Set swappiness to 10 (reduces swap usage)"
    )
    
    # Set vfs_cache_pressure
    run_command(
        ["sysctl", "-w", "vm.vfs_cache_pressure=50"],
        "Optimized VFS cache pressure"
    )
    
    # Make persistent
    sysctl_conf = "/etc/sysctl.d/99-optimizer.conf"
    try:
        with open(sysctl_conf, 'w') as f:
            f.write("# Ubuntu Optimizer Settings\n")
            f.write("vm.swappiness=10\n")
            f.write("vm.vfs_cache_pressure=50\n")
        print_success("Made swap settings persistent")
    except:
        print_warning("Could not save persistent settings")


def clear_ram_cache():
    """Clear RAM cache (sync first to prevent data loss)."""
    print_header("Clearing RAM Cache")
    
    # Sync filesystem first
    run_command(["sync"], "Synced filesystem")
    
    # Clear PageCache, dentries and inodes
    try:
        with open("/proc/sys/vm/drop_caches", "w") as f:
            f.write("3")
        print_success("Cleared RAM cache (PageCache, dentries, inodes)")
    except:
        print_warning("Could not clear RAM cache")


def disable_unnecessary_services():
    """Suggest disabling unnecessary services."""
    print_header("Service Recommendations")
    
    # Services that might not be needed on a laptop
    optional_services = [
        ("bluetooth.service", "Bluetooth (if not using Bluetooth devices)"),
        ("cups.service", "Printing service (if not using printers)"),
        ("avahi-daemon.service", "Network discovery (if not needed)"),
        ("ModemManager.service", "Modem manager (if not using mobile broadband)"),
    ]
    
    print(f"\n{Colors.YELLOW}Optional services you might consider disabling:{Colors.END}")
    print("(Only disable if you don't use the feature)\n")
    
    for service, description in optional_services:
        result = subprocess.run(
            ["systemctl", "is-active", service],
            capture_output=True, text=True
        )
        status = "running" if result.returncode == 0 else "not running"
        print(f"  • {service}: {description}")
        print(f"    Status: {status}")
        print(f"    To disable: sudo systemctl disable --now {service}\n")


def optimize_io_scheduler():
    """Set optimal I/O scheduler for SSDs."""
    print_header("I/O Scheduler Optimization")
    
    # Check for NVMe/SSD and set appropriate scheduler
    for disk in Path("/sys/block").iterdir():
        if disk.name.startswith(('sd', 'nvme')):
            rotational_file = disk / "queue" / "rotational"
            scheduler_file = disk / "queue" / "scheduler"
            
            if rotational_file.exists() and scheduler_file.exists():
                try:
                    rotational = rotational_file.read_text().strip()
                    if rotational == "0":  # SSD
                        # Try to set none/noop for SSDs
                        try:
                            scheduler_file.write_text("none")
                            print_success(f"Set 'none' scheduler for SSD {disk.name}")
                        except:
                            try:
                                scheduler_file.write_text("mq-deadline")
                                print_success(f"Set 'mq-deadline' scheduler for SSD {disk.name}")
                            except:
                                print_warning(f"Could not change scheduler for {disk.name}")
                except:
                    pass


def preload_setup():
    """Install and configure preload for faster app launching."""
    print_header("Preload Setup")
    
    result = subprocess.run(["which", "preload"], capture_output=True)
    if result.returncode != 0:
        print(f"{Colors.YELLOW}Preload is not installed.{Colors.END}")
        print("Preload learns which applications you use most and preloads them.")
        print(f"To install: {Colors.BOLD}sudo apt install preload{Colors.END}")
    else:
        print_success("Preload is already installed")


def trim_ssd():
    """Run TRIM on SSDs for better performance."""
    print_header("SSD TRIM")
    run_command(["fstrim", "-av"], "Ran TRIM on all mounted filesystems")


def show_summary(free_before, free_after):
    """Show optimization summary."""
    print_header("Optimization Complete!")
    
    freed = free_after - free_before
    print(f"\n{Colors.BOLD}Summary:{Colors.END}")
    print(f"  • Disk space before: {free_before} GB free")
    print(f"  • Disk space after:  {free_after} GB free")
    if freed > 0:
        print(f"  • Space recovered:   {Colors.GREEN}{freed} GB{Colors.END}")
    
    print(f"\n{Colors.BOLD}Additional Tips for Better Performance:{Colors.END}")
    print("  1. Consider using a lightweight desktop environment (XFCE, LXDE)")
    print("  2. Disable startup applications you don't need")
    print("  3. Use 'htop' to monitor resource usage")
    print("  4. Keep your system updated: sudo apt update && sudo apt upgrade")
    print("  5. Consider adding more RAM if frequently using swap")
    print("  6. Use an SSD if you haven't already")
    print()


def main():
    print(f"""
{Colors.BOLD}{Colors.BLUE}
╔═══════════════════════════════════════════════════════════╗
║           Ubuntu Laptop Optimizer v1.0                   ║
║   Speeds up your system without deleting permanent files  ║
╚═══════════════════════════════════════════════════════════╝
{Colors.END}""")

    if not check_root():
        return 1
    
    # Get disk space before optimization
    free_before = get_disk_space()
    
    # Run all optimizations
    clear_apt_cache()
    clear_old_kernels()
    clear_system_logs()
    clear_thumbnail_cache()
    clear_temp_files()
    clear_user_caches()
    clear_crash_reports()
    clear_ram_cache()
    optimize_swappiness()
    optimize_io_scheduler()
    trim_ssd()
    preload_setup()
    disable_unnecessary_services()
    
    # Get disk space after optimization
    free_after = get_disk_space()
    
    # Show summary
    show_summary(free_before, free_after)
    
    return 0


if __name__ == "__main__":
    exit(main())
