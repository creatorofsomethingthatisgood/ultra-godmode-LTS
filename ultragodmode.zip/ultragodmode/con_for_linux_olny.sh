#!/usr/bin/env bash

clear
cat << "EOF"
=======================================
  Ultra God Mode Tweaks Assistant (2026)
  Interactive Linux optimizer / privacy
  Answer y/n/s (yes/no/skip) for each
=======================================
EOF

tweaks=(
  "1|Disable mitigations for max performance (Spectre/Meltdown)|Gaming/throughput boost, small security risk on trusted machine|kernel cmdline: mitigations=off"
  "2|Enable zram (compressed RAM swap)|Much faster swap than disk → better low-RAM performance|Install zram-config or systemd-swap"
  "3|Disable telemetry / error reporting (Ubuntu/Pop!_OS example)|More privacy, less background network|sudo apt remove ubuntu-report popularity-contest apport whoopsie"
  "4|Set swappiness to 10 (less aggressive swapping)|Keeps more in RAM → snappier system|echo 'vm.swappiness=10' | sudo tee -a /etc/sysctl.conf && sudo sysctl -p"
  "5|Install/Enable earlyoom (kill heavy processes before OOM)|Prevents full freezes on low memory|sudo apt install earlyoom && sudo systemctl enable --now earlyoom"
  "6|Disable Bluetooth if unused|Small power/attack surface save|sudo systemctl disable --now bluetooth"
)

i=0
for entry in "${tweaks[@]}"; do
  ((i++))
  IFS='|' read -r num title why cmd <<< "$entry"

  echo ""
  echo "[$i/${#tweaks[@]}] $title"
  echo "Why: $why"
  echo ""
  read -p "Apply? (y/n/s): " choice

  case "$choice" in
    [Yy]* )
      echo "[+] Applying..."
      if [[ "$cmd" == sudo* ]]; then
        eval "$cmd"
      else
        eval "$cmd"
      fi
      echo "Done."
      ;;
    [Nn]* )
      echo "[-] Skipped (no change)"
      ;;
    * )
      echo "[s] Skipped"
      ;;
  esac
  sleep 1
done

echo ""
echo "======================================="
echo "  Finished! Some changes need reboot."
echo "  Re-run script anytime to adjust."
echo "======================================="
read -p "Press Enter to exit..."
