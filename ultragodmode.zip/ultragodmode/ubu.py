import os
import subprocess
import sys
import re
import time

# --- Configuration & Colors ---
LOG_FILE = "ubuguard_report.txt"
ISSUES_FOUND = []

class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

# --- Helper Functions ---
def clear_screen():
    os.system('clear')

def log_issue(issue, risk_level):
    """Adds an issue to the session report list."""
    ISSUES_FOUND.append(f"[{risk_level}] {issue}")

def print_banner():
    clear_screen()
    print(Colors.HEADER + Colors.BOLD + r"""
   __  __  _           ____                      _ 
  |  ||  || |__  _   _/ ___| _   _  __ _ _ __ __| |
  |  ||  || '_ \| | | | |  _| | | |/ _` | '__/ _` |
  |  ||  || |_) | |_| | |_| | |_| | (_| | | | (_| |
   \____/ |_.__/ \__,_|\____|\__,_|\__,_|_|  \__,_|
    """ + Colors.ENDC)
    print(f"{Colors.BLUE}   Ubuntu Security Optimizer & Hardening Tool{Colors.ENDC}")
    print("   ------------------------------------------\n")

def check_root():
    if os.geteuid() != 0:
        print(f"{Colors.FAIL}[CRITICAL] This script requires Root privileges.{Colors.ENDC}")
        print("Please run with: sudo python3 ubuguard.py")
        sys.exit(1)

# --- Security Modules ---

def audit_firewall():
    print(f"\n{Colors.BOLD}--- Auditing Firewall (UFW) ---{Colors.ENDC}")
    time.sleep(0.5) # Simulate processing
    
    try:
        status = subprocess.check_output("ufw status", shell=True).decode().lower()
        if "active" in status and "inactive" not in status:
            print(f"{Colors.GREEN}[PASS] Firewall is Active.{Colors.ENDC}")
        else:
            print(f"{Colors.FAIL}[HIGH RISK] Firewall is INACTIVE.{Colors.ENDC}")
            log_issue("Firewall is inactive", "HIGH")
            
            choice = input(f"{Colors.WARNING}>>> Would you like to enable UFW and deny incoming traffic? (y/n): {Colors.ENDC}")
            if choice.lower() == 'y':
                os.system("ufw default deny incoming > /dev/null")
                os.system("ufw default allow outgoing > /dev/null")
                os.system("ufw enable")
                print(f"{Colors.GREEN}[FIXED] Firewall enabled and secured.{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}[ERROR] Could not check firewall: {e}{Colors.ENDC}")
    
    input(f"\n{Colors.BLUE}Press Enter to return to menu...{Colors.ENDC}")

def audit_ssh():
    print(f"\n{Colors.BOLD}--- Auditing SSH Configuration ---{Colors.ENDC}")
    time.sleep(0.5)
    
    config_path = "/etc/ssh/sshd_config"
    if not os.path.exists(config_path):
        print(f"{Colors.WARNING}[SKIP] SSH config not found (SSH might not be installed).{Colors.ENDC}")
        return

    # Check Root Login
    try:
        with open(config_path, 'r') as f:
            content = f.read()
            
        # Regex to find PermitRootLogin independent of comments
        if re.search(r"^PermitRootLogin\s+yes", content, re.MULTILINE):
            print(f"{Colors.FAIL}[HIGH RISK] Root login over SSH is ALLOWED.{Colors.ENDC}")
            log_issue("Root SSH login allowed", "HIGH")
            
            print(f"{Colors.BOLD}Explanation:{Colors.ENDC} Attackers target the 'root' account first.")
            choice = input(f"{Colors.WARNING}>>> Disable Root SSH Login? (y/n): {Colors.ENDC}")
            if choice.lower() == 'y':
                # Create backup
                os.system(f"cp {config_path} {config_path}.bak")
                # Apply fix using sed
                os.system(f"sed -i 's/^PermitRootLogin yes/PermitRootLogin no/' {config_path}")
                # Restart SSH
                os.system("systemctl restart sshd")
                print(f"{Colors.GREEN}[FIXED] Root login disabled.{Colors.ENDC}")
        else:
            print(f"{Colors.GREEN}[PASS] Root SSH login is disabled (or not explicitly enabled).{Colors.ENDC}")

    except Exception as e:
        print(f"{Colors.FAIL}[ERROR] Failed to audit SSH: {e}{Colors.ENDC}")

    input(f"\n{Colors.BLUE}Press Enter to return to menu...{Colors.ENDC}")

def audit_system_updates():
    print(f"\n{Colors.BOLD}--- Auditing System Updates ---{Colors.ENDC}")
    print("Checking for available security updates (this may take a moment)...")
    
    # Update package lists first
    os.system("apt-get update > /dev/null 2>&1")
    
    # Simulate checking for upgrades
    upgrades = subprocess.check_output("apt list --upgradable 2>/dev/null | grep -i security | wc -l", shell=True).decode().strip()
    
    count = int(upgrades)
    if count > 0:
        print(f"{Colors.FAIL}[MEDIUM RISK] Found {count} security updates pending.{Colors.ENDC}")
        log_issue(f"{count} Security updates pending", "MEDIUM")
        
        choice = input(f"{Colors.WARNING}>>> Install security updates now? (y/n): {Colors.ENDC}")
        if choice.lower() == 'y':
            print("Installing updates... please wait.")
            os.system("apt-get upgrade -y")
            print(f"{Colors.GREEN}[FIXED] System is up to date.{Colors.ENDC}")
    else:
        print(f"{Colors.GREEN}[PASS] No immediate security updates found.{Colors.ENDC}")

    input(f"\n{Colors.BLUE}Press Enter to return to menu...{Colors.ENDC}")

def generate_report():
    print(f"\n{Colors.BOLD}--- Generating Session Report ---{Colors.ENDC}")
    if not ISSUES_FOUND:
        print(f"{Colors.GREEN}Great news! No significant issues were logged this session.{Colors.ENDC}")
    else:
        print(f"{Colors.FAIL}Issues identified during this session:{Colors.ENDC}")
        with open(LOG_FILE, "w") as f:
            f.write("UbuGuard Security Report\n")
            f.write("========================\n")
            for item in ISSUES_FOUND:
                print(f" - {item}")
                f.write(f"- {item}\n")
        print(f"\nReport saved to: {Colors.BOLD}{os.getcwd()}/{LOG_FILE}{Colors.ENDC}")
    
    input(f"\n{Colors.BLUE}Press Enter to return to menu...{Colors.ENDC}")

# --- Main Logic Loop ---

def main_menu():
    while True:
        print_banner()
        print(f"{Colors.BOLD}Select an Option:{Colors.ENDC}")
        print("1. Run Firewall Audit (Network)")
        print("2. Run SSH Hardening Audit (Remote Access)")
        print("3. Check System Updates (Patching)")
        print("4. Generate & View Report")
        print("5. Exit UbuGuard")
        
        choice = input(f"\n{Colors.BLUE}Enter choice [1-5]: {Colors.ENDC}")
        
        if choice == '1':
            audit_firewall()
        elif choice == '2':
            audit_ssh()
        elif choice == '3':
            audit_system_updates()
        elif choice == '4':
            generate_report()
        elif choice == '5':
            print(f"\n{Colors.GREEN}Stay Safe! Exiting...{Colors.ENDC}")
            break
        else:
            print(f"{Colors.FAIL}Invalid option. Try again.{Colors.ENDC}")
            time.sleep(1)

if __name__ == "__main__":
    try:
        check_root()
        main_menu()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.WARNING}Force Close Detected. Exiting...{Colors.ENDC}")
        sys.exit(0)
