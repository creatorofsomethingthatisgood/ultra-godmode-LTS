mitmdump -s adblock_proxy.py --listen-port 8888
